<?php

namespace App\Services\Cashback;

use App\Models\CashbackCampaign;
use Illuminate\Support\Collection;
use App\Models\User;
use App\Models\CashbackTransaction;
use App\Models\Invoice;
use App\Models\RankingReward;
use App\Models\CashbackCampaignWinner;

class CalculateRankingCashbackService
{
    /**
     * Obtener los participantes de la campaña.
     */
    protected function getParticipants(
        CashbackCampaign $campaign
    ): Collection {

        return $campaign->scopes;
    }
    /**
     * Calcular el ranking de un almacén.
     */
    protected function calculateWarehouseRanking(
        CashbackCampaign $campaign,
        int $warehouseId
    ): ?object {

        return Invoice::query()

            ->selectRaw('
            user_id,
            SUM(total_productos_participantes) as total_ventas,
            SUM(cashback_generado) as total_cashback
        ')

            ->join(
                'branches',
                'branches.id',
                '=',
                'invoices.branch_id'
            )

            ->where(
                'cashback_campaign_id',
                $campaign->id
            )

            ->where(
                'branches.warehouse_id',
                $warehouseId
            )

            ->groupBy('user_id')

            ->orderByDesc(

                $campaign->ranking_type === 'sales'

                    ? 'total_ventas'

                    : 'total_cashback'

            )

            ->first();
    }
    /**
     * Calcular el ranking de una zona.
     */
    protected function calculateZoneRanking(
        CashbackCampaign $campaign,
        int $zoneId
    ): ?object {

        return Invoice::query()

            ->selectRaw('
            user_id,
            SUM(total_productos_participantes) as total_ventas,
            SUM(cashback_generado) as total_cashback
        ')

            ->join(
                'branches',
                'branches.id',
                '=',
                'invoices.branch_id'
            )

            ->where(
                'cashback_campaign_id',
                $campaign->id
            )

            ->where(
                'branches.zone_id',
                $zoneId
            )

            ->groupBy('user_id')

            ->orderByDesc(

                $campaign->ranking_type === 'sales'

                    ? 'total_ventas'

                    : 'total_cashback'

            )

            ->first();
    }
    /**
     * Calcular el ranking de una sucursal.
     */
    protected function calculateBranchRanking(
        CashbackCampaign $campaign,
        int $branchId
    ): ?object {

        return Invoice::query()

            ->selectRaw('
            user_id,
            SUM(total_productos_participantes) as total_ventas,
            SUM(cashback_generado) as total_cashback
        ')

            ->where(
                'cashback_campaign_id',
                $campaign->id
            )

            ->where(
                'branch_id',
                $branchId
            )

            ->groupBy('user_id')

            ->orderByDesc(

                $campaign->ranking_type === 'sales'

                    ? 'total_ventas'

                    : 'total_cashback'

            )

            ->first();
    }
    /**
     * Ejecutar el cálculo del Ranking Cashback.
     */
    public function execute(
        CashbackCampaign $campaign
    ): void {
        if (! $campaign->activo) {
            return;
        }

        if ($campaign->campaign_type !== 'cashback') {
            return;
        }

        if ($campaign->ranking_processed) {
            return;
        }

        if (! $campaign->ranking_enabled) {
            return;
        }

        $participants = $this->getParticipants(
            $campaign
        );
        foreach ($participants as $participant) {

            $winner = null;

            switch ($campaign->participant_type) {

                case 'warehouse':

                    if (! $participant->warehouse_id) {
                        continue 2;
                    }

                    $winner = $this->calculateWarehouseRanking(
                        $campaign,
                        $participant->warehouse_id
                    );

                    break;

                case 'zone':

                    if (! $participant->zone_id) {
                        continue 2;
                    }

                    $winner = $this->calculateZoneRanking(
                        $campaign,
                        $participant->zone_id
                    );

                    break;

                case 'branch':

                    if (! $participant->branch_id) {
                        continue 2;
                    }

                    $winner = $this->calculateBranchRanking(
                        $campaign,
                        $participant->branch_id
                    );

                    break;

                default:

                    $winner = $this->calculateGeneralRanking(
                        $campaign
                    );

                    break;
            }

            if (! $winner) {
                continue;
            }

            $this->rewardWinner(
                $campaign,
                $winner
            );
        }
        $campaign->update([

            'ranking_processed' => true,

        ]);
    }
    /**
     * Calcular el ranking general.
     */
    protected function calculateGeneralRanking(
        CashbackCampaign $campaign
    ): ?object {

        return Invoice::query()

            ->selectRaw('
            user_id,
            SUM(total_productos_participantes) as total_ventas,
            SUM(cashback_generado) as total_cashback
        ')

            ->where(
                'cashback_campaign_id',
                $campaign->id
            )

            ->groupBy('user_id')

            ->orderByDesc(

                $campaign->ranking_type === 'sales'

                    ? 'total_ventas'

                    : 'total_cashback'

            )

            ->first();
    }
    /**
     * Entregar el premio al ganador.
     */
    protected function rewardWinner(
        CashbackCampaign $campaign,
        object $winner
    ): void {

        $reward = RankingReward::query()

            ->where(
                'cashback_campaign_id',
                $campaign->id
            )

            ->where(
                'activo',
                true
            )

            ->where(
                'posicion',
                1
            )

            ->first();

        if (! $reward) {
            return;
        }

        $user = User::find(
            $winner->user_id
        );

        if (! $user) {
            return;
        }

        /*
    |--------------------------------------------------------------------------
    | Calcular bono adicional
    |--------------------------------------------------------------------------
    */

        $cashbackOriginal = $winner->total_cashback;

        $cashbackFinal =
            $cashbackOriginal *
            $reward->multiplicador;

        $bono =
            $cashbackFinal -
            $cashbackOriginal;

        if ($bono <= 0) {
            return;
        }

        /*
    |--------------------------------------------------------------------------
    | Actualizar saldos
    |--------------------------------------------------------------------------
    */

        $user->increment(
            'cashback_total',
            $bono
        );

        $user->increment(
            'cashback_available',
            $bono
        );

        $user->refresh();
        /*
|--------------------------------------------------------------------------
| Registrar ganador
|--------------------------------------------------------------------------
*/

        CashbackCampaignWinner::updateOrCreate(

            [
                'cashback_campaign_id' => $campaign->id,
                'user_id' => $user->id,
            ],

            [
                'warehouse_id' => $user->warehouse_id,

                'zone_id' => $user->zone_id,

                'branch_id' => $user->branch_id,

                'ranking_position' => 1,

                'sales_total' => $winner->total_ventas,

                'cashback_total' => $winner->total_cashback,

                'bonus_amount' => $bono,

                'reward_type_id' => $reward->reward_type_id,

                'ranking_reward_id' => $reward->id,

                'reward_title' => $reward->titulo,

                'reward_value' => $reward->valor_referencial,

                'reward_multiplier' => $reward->multiplicador,

                'processed_at' => now(),
            ]

        );
        /*
    |--------------------------------------------------------------------------
    | Registrar movimiento
    |--------------------------------------------------------------------------
    */

        CashbackTransaction::create([

            'user_id' =>
            $user->id,

            'invoice_id' =>
            null,

            'cashback_campaign_id' =>
            $campaign->id,

            'tipo' =>
            'ranking_bonus',

            'movimiento' =>
            'ingreso',

            'valor' =>
            $bono,

            'saldo_despues' =>
            $user->cashback_available,

            'descripcion' =>

            'Premio Ranking Cashback - '
                . $campaign->nombre,

        ]);
    }
}
