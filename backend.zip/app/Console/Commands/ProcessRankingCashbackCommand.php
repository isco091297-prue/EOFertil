<?php

namespace App\Console\Commands;

use App\Models\CashbackCampaign;
use App\Services\Cashback\CalculateRankingCashbackService;
use Illuminate\Console\Command;

class ProcessRankingCashbackCommand extends Command
{
    /**
     * Nombre del comando.
     */
    protected $signature = 'cashback:process-ranking';

    /**
     * Descripción.
     */
    protected $description =
    'Procesa automáticamente los rankings de cashback finalizados.';

    public function __construct(
        protected CalculateRankingCashbackService $service
    ) {
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle(): int
    {

        $campaigns = CashbackCampaign::query()

            ->where('campaign_type', 'cashback')

            ->where('ranking_enabled', true)

            ->where('ranking_processed', false)

            ->where('activo', true)

            ->whereDate(
                'fecha_fin',
                '<',
                now()->toDateString()
            )

            ->get();

        foreach ($campaigns as $campaign) {

            $this->info(
                "Procesando campaña {$campaign->nombre}"
            );

            $this->service->execute($campaign);

            $campaign->update([

                'ranking_processed' => true,

            ]);
        }

        $this->info('Proceso terminado.');

        return self::SUCCESS;
    }
}
